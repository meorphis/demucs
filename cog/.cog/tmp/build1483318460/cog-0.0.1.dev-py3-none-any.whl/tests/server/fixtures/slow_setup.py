import time


class Predictor:
    def setup(self):
        time.sleep(2)

    def predict(self) -> int:
        return 3
